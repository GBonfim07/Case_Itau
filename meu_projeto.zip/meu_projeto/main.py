# arquivo: main.py
from app.services import ExecutarTransacaoFinanceira
from app.transacoes import TransacaoFactory
from app.data_access import AcessoDados

if __name__ == "__main__":
    # Criar as transações
    transacoes = [
        TransacaoFactory.criar_transacao(1, "09/09/2023 14:15:00", 938485762, 2147483649, 150),
        TransacaoFactory.criar_transacao(2, "09/09/2023 14:15:05", 2147483649, 210385733, 149),
        TransacaoFactory.criar_transacao(3, "09/09/2023 14:15:29", 347586970, 238596054, 1100),
        TransacaoFactory.criar_transacao(4, "09/09/2023 14:17:00", 675869708, 210385733, 5300),
        TransacaoFactory.criar_transacao(5, "09/09/2023 14:18:00", 238596054, 674038564, 1489),
        TransacaoFactory.criar_transacao(6, "09/09/2023 14:18:20", 573659065, 563856300, 49),
        TransacaoFactory.criar_transacao(7, "09/09/2023 14:19:00", 938485762, 2147483649, 44),
        TransacaoFactory.criar_transacao(8, "09/09/2023 14:19:01", 573659065, 675869708, 150)
    ]

    # Criar o objeto de acesso a dados e executor
    acesso_dados = AcessoDados()
    executor = ExecutarTransacaoFinanceira(acesso_dados)

    # Executar as transações
    for transacao in transacoes:
        executor.transferir(transacao)

    # Mostrar o resultado final
    for resultado in executor.resultados_transacoes:
        print(resultado)
