# arquivo: models.py

class Transacao:
    def __init__(self, correlation_id, data_hora, conta_origem, conta_destino, valor):
        self.correlation_id = correlation_id
        self.data_hora = data_hora
        self.conta_origem = conta_origem
        self.conta_destino = conta_destino
        self.valor = valor

class ContaSaldo:
    def __init__(self, conta, saldo):
        self.conta = conta
        self.saldo = saldo
