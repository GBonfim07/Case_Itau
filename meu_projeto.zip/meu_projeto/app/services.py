# arquivo: services.py
from app.data_access import AcessoDados
from app.models import Transacao
from threading import Lock

class ExecutarTransacaoFinanceira:
    def __init__(self, acesso_dados: AcessoDados):
        self.acesso_dados = acesso_dados
        self.lock = Lock()
        self.resultados_transacoes = []  # Armazena os resultados das transações

    def transferir(self, transacao):
        with self.lock:
            conta_origem = self.acesso_dados.get_saldo(transacao.conta_origem)
            if conta_origem is None or conta_origem.saldo < transacao.valor:
                status = "Cancelada por falta de saldo"
                self.resultados_transacoes.append({
                    'Transação Número': transacao.correlation_id,
                    'Conta Origem': transacao.conta_origem,
                    'Conta Destino': transacao.conta_destino,
                    'Valor': transacao.valor,
                    'Saldo Conta Origem': None,
                    'Saldo Conta Destino': None,
                    'Status': status
                })
                print(f"Transação número {transacao.correlation_id} foi cancelada por falta de saldo")
                return

            conta_destino = self.acesso_dados.get_saldo(transacao.conta_destino)
            if conta_destino is None:
                status = "Falhou: conta de destino não encontrada"
                self.resultados_transacoes.append({
                    'Transação Número': transacao.correlation_id,
                    'Conta Origem': transacao.conta_origem,
                    'Conta Destino': transacao.conta_destino,
                    'Valor': transacao.valor,
                    'Saldo Conta Origem': conta_origem.saldo,
                    'Saldo Conta Destino': None,
                    'Status': status
                })
                print(f"Transação número {transacao.correlation_id} falhou: conta de destino não encontrada")
                return

            conta_origem.saldo -= transacao.valor
            conta_destino.saldo += transacao.valor

            self.acesso_dados.atualizar(conta_origem)
            self.acesso_dados.atualizar(conta_destino)

            status = "Concluída"
            self.resultados_transacoes.append({
                'Transação Número': transacao.correlation_id,
                'Conta Origem': transacao.conta_origem,
                'Conta Destino': transacao.conta_destino,
                'Valor': transacao.valor,
                'Saldo Conta Origem': conta_origem.saldo,
                'Saldo Conta Destino': conta_destino.saldo,
                'Status': status
            })

            print(f"Transação número {transacao.correlation_id} foi efetivada com sucesso! "
                  f"Novos saldos: Conta Origem: {conta_origem.saldo} | Conta Destino: {conta_destino.saldo}")
