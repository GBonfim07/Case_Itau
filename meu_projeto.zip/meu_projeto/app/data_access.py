# arquivo: data_access.py
from threading import Lock
from app.models import ContaSaldo

class AcessoDados:
    def __init__(self):
        self.tabela_saldos = [
            ContaSaldo(938485762, 180),
            ContaSaldo(347586970, 1200),
            ContaSaldo(2147483649, 0),
            ContaSaldo(675869708, 4900),
            ContaSaldo(238596054, 478),
            ContaSaldo(573659065, 787),
            ContaSaldo(210385733, 10),
            ContaSaldo(674038564, 400),
            ContaSaldo(563856300, 1200)
        ]
        self.lock = Lock()

    def get_saldo(self, conta):
        for saldo in self.tabela_saldos:
            if saldo.conta == conta:
                return saldo
        return None

    def atualizar(self, conta_saldo):
        with self.lock:
            for idx, saldo in enumerate(self.tabela_saldos):
                if saldo.conta == conta_saldo.conta:
                    self.tabela_saldos[idx] = conta_saldo
                    return True
        return False
