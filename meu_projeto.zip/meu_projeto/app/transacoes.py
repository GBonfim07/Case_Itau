# arquivo: transacoes.py
from app.models import Transacao

class TransacaoFactory:
    @staticmethod
    def criar_transacao(correlation_id, data_hora, conta_origem, conta_destino, valor):
        return Transacao(correlation_id, data_hora, conta_origem, conta_destino, valor)
