import pandas as pd
from concurrent.futures import ThreadPoolExecutor
from threading import Lock

class IAcessoDados:
    def get_saldo(self, conta):
        raise NotImplementedError

    def atualizar(self, conta_saldo):
        raise NotImplementedError


# Classe ContaSaldo (Model) - Respeita o Princípio de Responsabilidade Única (S do SOLID)
class ContaSaldo:
    def __init__(self, conta, saldo):
        self.conta = conta
        self.saldo = saldo

# Implementação da interface de acesso a dados (Repository Pattern)
class AcessoDados(IAcessoDados):
    def __init__(self):
        self.tabela_saldos = [
            ContaSaldo(938485762, 180),
            ContaSaldo(347586970, 1200),
            ContaSaldo(2147483649, 0),
            ContaSaldo(675869708, 4900),
            ContaSaldo(238596054, 478),
            ContaSaldo(573659065, 787),
            ContaSaldo(210385733, 10),
            ContaSaldo(674038564, 400),
            ContaSaldo(563856300, 1200)
        ]
        self.lock = Lock()

    def get_saldo(self, conta):
        for saldo in self.tabela_saldos:
            if saldo.conta == conta:
                return saldo
        return None

    def atualizar(self, conta_saldo):
        with self.lock:
            for idx, saldo in enumerate(self.tabela_saldos):
                if saldo.conta == conta_saldo.conta:
                    self.tabela_saldos[idx] = conta_saldo
                    return True
        return False



class Transacao:
    def __init__(self, correlation_id, data_hora, conta_origem, conta_destino, valor):
        self.correlation_id = correlation_id
        self.data_hora = data_hora
        self.conta_origem = conta_origem
        self.conta_destino = conta_destino
        self.valor = valor

# Fábrica de Transações (Factory Pattern)
class TransacaoFactory:
    @staticmethod
    def criar_transacao(correlation_id, data_hora, conta_origem, conta_destino, valor):
        return Transacao(correlation_id, data_hora, conta_origem, conta_destino, valor)


class ExecutarTransacaoFinanceira:
    def __init__(self, acesso_dados: IAcessoDados):
        self.acesso_dados = acesso_dados
        self.lock = Lock()
        self.resultados_transacoes = []  # Armazena os resultados das transações

    def transferir(self, transacao):
        with self.lock:
            conta_origem = self.acesso_dados.get_saldo(transacao.conta_origem)
            if conta_origem is None or conta_origem.saldo < transacao.valor:
                status = "Cancelada por falta de saldo"
                self.resultados_transacoes.append({
                    'Transação Número': transacao.correlation_id,
                    'Conta Origem': transacao.conta_origem,
                    'Conta Destino': transacao.conta_destino,
                    'Valor': transacao.valor,
                    'Saldo Conta Origem': None,
                    'Saldo Conta Destino': None,
                    'Status': status
                })
                print(f"Transação número {transacao.correlation_id} foi cancelada por falta de saldo")
                return

            conta_destino = self.acesso_dados.get_saldo(transacao.conta_destino)
            if conta_destino is None:
                status = "Falhou: conta de destino não encontrada"
                self.resultados_transacoes.append({
                    'Transação Número': transacao.correlation_id,
                    'Conta Origem': transacao.conta_origem,
                    'Conta Destino': transacao.conta_destino,
                    'Valor': transacao.valor,
                    'Saldo Conta Origem': conta_origem.saldo,
                    'Saldo Conta Destino': None,
                    'Status': status
                })
                print(f"Transação número {transacao.correlation_id} falhou: conta de destino não encontrada")
                return

            conta_origem.saldo -= transacao.valor
            conta_destino.saldo += transacao.valor

            self.acesso_dados.atualizar(conta_origem)
            self.acesso_dados.atualizar(conta_destino)

            status = "Concluída"
            self.resultados_transacoes.append({
                'Transação Número': transacao.correlation_id,
                'Conta Origem': transacao.conta_origem,
                'Conta Destino': transacao.conta_destino,
                'Valor': transacao.valor,
                'Saldo Conta Origem': conta_origem.saldo,
                'Saldo Conta Destino': conta_destino.saldo,
                'Status': status
            })

            print(f"Transação número {transacao.correlation_id} foi efetivada com sucesso! "
                  f"Novos saldos: Conta Origem: {conta_origem.saldo} | Conta Destino: {conta_destino.saldo}")

# Simulação de execução, agora com as transações ordenadas pelos IDs
if __name__ == "__main__":
    transacoes = [
        TransacaoFactory.criar_transacao(1, "09/09/2023 14:15:00", 938485762, 2147483649, 150),
        TransacaoFactory.criar_transacao(2, "09/09/2023 14:15:05", 2147483649, 210385733, 149),
        TransacaoFactory.criar_transacao(3, "09/09/2023 14:15:29", 347586970, 238596054, 1100),
        TransacaoFactory.criar_transacao(4, "09/09/2023 14:17:00", 675869708, 210385733, 5300),
        TransacaoFactory.criar_transacao(5, "09/09/2023 14:18:00", 238596054, 674038564, 1489),
        TransacaoFactory.criar_transacao(6, "09/09/2023 14:18:20", 573659065, 563856300, 49),
        TransacaoFactory.criar_transacao(7, "09/09/2023 14:19:00", 938485762, 2147483649, 44),
        TransacaoFactory.criar_transacao(8, "09/09/2023 14:19:01", 573659065, 675869708, 150)
    ]

    acesso_dados = AcessoDados()
    executor = ExecutarTransacaoFinanceira(acesso_dados)

    # Ordenando as transações pela ordem do correlation_id
    transacoes_ordenadas = sorted(transacoes, key=lambda t: t.correlation_id)

    # Executando as transações em paralelo, mas respeitando a ordem de execução
    with ThreadPoolExecutor() as executor_pool:
        executor_pool.map(executor.transferir, transacoes_ordenadas)

    # Criar um DataFrame com os resultados ordenados pelo número da transação
    df = pd.DataFrame(sorted(executor.resultados_transacoes, key=lambda t: t['Transação Número']))

    # Exibir o DataFrame
    print(df)
    df.to_excel(r'C:\Users\gubon\Downloads\meu_projeto\Case_itau\resultado.xlsx',index=False)